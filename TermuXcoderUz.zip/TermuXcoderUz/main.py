from colorama import Fore
import os
import sys
import json

FUNKSIYA_FAYLI = "yangi_opsiyalar.json"
yangi_opsiyalar = []

def yuklash_yangi_opsiyalar():
    global yangi_opsiyalar
    if os.path.exists(FUNKSIYA_FAYLI):
        with open(FUNKSIYA_FAYLI, "r") as fayl:
            yangi_opsiyalar = json.load(fayl)
    else:
        yangi_opsiyalar = []

def saqlash_yangi_opsiyalar():
    with open(FUNKSIYA_FAYLI, "w") as fayl:
        json.dump(yangi_opsiyalar, fayl)

def display_menu():
    print()
    print()
    print(f'    {Fore.CYAN}╔════════════════════════════════════════════════════════════════════════╗')
    print(f'    {Fore.CYAN}║                               Main Menu                               ║')
    print(f'    {Fore.CYAN}╠════════════════════════════════════════════════════════════════════════╣')

    bloklar = [
        (
            "Telegram akkaunt boshqaruvi",
            [
                "[ 0 ] Yangi funksiya qo'shish",
                "[ 1 ] Raqamlarni tekshirish",
                "[ 2 ] Nomer ulash",
                "[ 3 ] Telegram akkauntdan kod olish",
                "[ 4 ] Ban akkauntlarni filtrlash",
                "[ 5 ] Session bazasini tozalash (kesh)",
                "[ 6 ] Eski seanslarni chiqarib tashlash",
                "[ 7 ] 2 bosqichli parol qo‘yish",
                "[ 8 ] 2 bosqichli parolni o‘zgartirish",
                "[ 9 ] 2 bosqichli parolni o‘chirish",
            ]
        ),
        (
            "Kanallar va guruhlar",
            [
                "[ 10 ] Telefon raqami davlatini tekshirish",
                "[ 11 ] Yopiq guruh/kanalga qo‘shilish",
                "[ 12 ] Kanallarga qo‘shilish",
                "[ 13 ] Barcha kanal/guruhdan chiqish",
                "[ 14 ] Belgilangan kanaldan chiqish",
                "[ 15 ] Rasm/Bio va boshqalarni koʻrinmaydigan qilish",
                "[ 16 ] Rasm/Bio va boshqalarni koʻrinadigan qilish",
                "[ 17 ] Barcha bot va foydalanuvchi o'chirish",
                "[ 18 ] Guruhga yoki lickaga yozish",
            ]
        ),
        (
            "Shaxsiy sozlamalar",
            [
                "[ 19 ] Tasodifiy ism qo‘yish",
                "[ 20 ] Tasodifiy bio qo‘yish",
                "[ 21 ] Tasodifiy tug‘ilgan kun qo‘yish",
                "[ 22 ] Tasodifiy familiya qo‘yish",
                "[ 23 ] Tasodifiy username qo‘yish",
                "[ 24 ] Username olib tashlash",
                "[ 25 ] Tasodifiy rasm qo'yish",
                "[ 26 ] Reklama berish",
            ]
        ),
        (
            "Faoliyat monitoringi",
            [
                "[ 27 ] Oxirgi 10 ta xabarga ko'rish qilish (view)",
                "[ 28 ] Postga reaksiya bosish",
                "[ 29 ] Story ga  PM va reaksiya yuborish",
                "[ 30 ] So‘rovnomaga ovoz berish (vote)",
                "[ 31 ] @BestRandom_bot  shablon",
                "[ 32 ] Premium/Stars yutuqni tekshirish",
            ]
        ),
        (
            "Bot va avtomatlashtirish",
            [
                "[ 33 ] Phone.csvdagi takroriy raqamlarni oʻchirish",
                "[ 34 ] Phone.csv faylini tozalash",
                "[ 35 ] Premiumi bor akkauntlarni ko'rish",
                "[ 36 ] 24/7 online rejim",
                "[ 37 ] Start/kanal/tasdiq/kontakt",
                "[ 38 ] Start + referal id",
                "[ 39 ] @CosmoRandomizebot  shablon",
            ]
        ),
        (
            "Foydalanuvchi ma’lumotlari va chiqish",
            [
                "[ 40 ] Akkount ma’lumotlarini ko‘rish",
                "[ 41 ] Hikoya joylash (story)",
                "[ 42 ] Premiumni botga yuborish (Livegram)",
                "[ 43 ] Sessionsdan chiqish (Log out) -> havfli",
                "[ 44 ] Stars bor hisoblarni ko'rish",
                "[ 45 ] Chatjild (folder) link orqali kanalga qo'shilish",
            ]
        )
    ]

    for nomi, opsiyalar in bloklar:
        print(f'    {Fore.CYAN}║ {Fore.YELLOW}{nomi:<66} {Fore.CYAN}║')
        print(f'    {Fore.CYAN}╠════════════════════════════════════════════════════════════════════════╣')
        for opsiya in opsiyalar:
            print(f'{Fore.GREEN}        {opsiya}')
        print(f'    {Fore.CYAN}╠════════════════════════════════════════════════════════════════════════╣')

    if yangi_opsiyalar:
        print(f'    {Fore.CYAN}║ {Fore.YELLOW}Yangi funksiyalar                                                  {Fore.CYAN}║')
        print(f'    {Fore.CYAN}╠════════════════════════════════════════════════════════════════════════╣')
        for opsiya in yangi_opsiyalar:
            print(f'{Fore.GREEN}        {opsiya}')
        print(f'    {Fore.CYAN}╠════════════════════════════════════════════════════════════════════════╣')

    # Dasturdan chiqish funksiyasini har doim oxirida ko‘rsatish
    chiqish_kod = 46 + len(yangi_opsiyalar)
    print(f'    {Fore.CYAN}║ {Fore.YELLOW}Dasturdan chiqish                                                  {Fore.CYAN}║')
    print(f'{Fore.GREEN}        [ {chiqish_kod} ] Dasturdan chiqish')
    print(f'    {Fore.CYAN}╚════════════════════════════════════════════════════════════════════════╝')

def enter_code():
    print()
    print()
    choice = input(f'{Fore.YELLOW}Iltimos, variantni tanlang: ')
    chiqish_kod = 46 + len(yangi_opsiyalar)

    if choice == str(chiqish_kod):
        print(f"{Fore.RED}Dasturdan chiqish...")
        sys.exit(0)

    if choice == "0":
        yangi_funksiya = input(f"{Fore.CYAN}Yangi funksiya nomini kiriting: ")
        yangi_opsiyalar.append(f"[ {chiqish_kod} ] {yangi_funksiya}")
        saqlash_yangi_opsiyalar()
        print(f"{Fore.GREEN}Yangi funksiya qo'shildi: {yangi_funksiya}")
    else:
        try:
            coded = choice
            print(f"{Fore.CYAN}Tanlangan funksiya: {coded}")
            os.system(f"python3 activate.py --code {coded}")
        except ValueError:
            print(f"{Fore.RED}Xatolik! Menudan to'g'ri tanlov kiriting!")

def main():
    yuklash_yangi_opsiyalar()
    while True:
        display_menu()
        enter_code()

if __name__ == "__main__":
    main()